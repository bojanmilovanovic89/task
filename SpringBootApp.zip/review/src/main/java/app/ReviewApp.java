package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewApp {

	public static void main(String[] args) throws SQLException, IOException {
		SpringApplication.run(ReviewApp.class, args);

		initDb();
	}

	private static void initDb() throws SQLException, IOException {
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		InputStream inputStream = classloader.getResourceAsStream("init.sql");
		InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
		BufferedReader reader = new BufferedReader(streamReader);

		String sql = "";
		for (String line; (line = reader.readLine()) != null;) {
			sql += line;
		}

		Connection conn = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");

		conn.prepareCall(sql).execute();
		conn.close();
	}
}
