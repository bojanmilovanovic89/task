package app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import model.Review;

@RestController
@RequestMapping("/api/review")
public class ReviewController {

	private static final String PASSWORD = "";
	private static final String USERNAME = "sa";
	private static final String JDBC_H2_TEST = "jdbc:h2:~/test";

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Void> create(@RequestBody Review review) throws SQLException {
		Connection conn = getConnection();

		conn.prepareCall("INSERT INTO REVIEW VALUES ('" + review.getProductId() + "'," + review.getAverageScore() + ","
				+ review.getNumberOfReviews() + ")").executeUpdate();

		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT)
	public ResponseEntity<Void> update(@RequestBody Review review) throws SQLException {
		Connection conn = getConnection();

		conn.prepareCall("UPDATE REVIEW SET AVG_REVIEW_SCORE = " + review.getAverageScore() + ", NUM_OF_REVIEWS = "
				+ review.getNumberOfReviews() + " WHERE PRODUCT_ID = '" + review.getProductId() + "'").executeUpdate();

		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@RequestMapping(value = "/{productId}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> delete(@PathVariable String productId) throws SQLException {
		Connection conn = getConnection();

		conn.prepareCall("DELETE FROM REVIEW WHERE PRODUCT_ID = '" + productId + "'").executeUpdate();

		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@RequestMapping(value = "/{productId}", method = RequestMethod.GET)
	public ResponseEntity<Review> getReview(@PathVariable String productId) throws SQLException {
		Connection conn = getConnection();
		ResultSet resultSet = conn.prepareCall("SELECT * FROM REVIEW WHERE PRODUCT_ID = '" + productId + "'")
				.executeQuery();

		ResponseEntity<Review> result;

		if (resultSet.next()) {
			Review review = new Review();
			review.setProductId(resultSet.getString("PRODUCT_ID"));
			review.setAverageScore(resultSet.getDouble("AVG_REVIEW_SCORE"));
			review.setNumberOfReviews(resultSet.getLong("NUM_OF_REVIEWS"));
			result = new ResponseEntity<Review>(review, HttpStatus.OK);
		} else {
			result = new ResponseEntity<Review>(HttpStatus.NOT_FOUND);
		}

		return result;
	}

	private Connection getConnection() throws SQLException {
		return DriverManager.getConnection(JDBC_H2_TEST, USERNAME, PASSWORD);
	}

}
