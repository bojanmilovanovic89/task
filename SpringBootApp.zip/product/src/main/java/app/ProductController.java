package app;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import model.Product;
import model.Review;

@RestController
@RequestMapping("/api/product")
public class ProductController {

	private static final String REVIEW_APP_URL = "http://localhost:8080/api/review/";
	private static final String ADIDAS_APP_URL = "https://www.adidas.co.uk/api/products/";

	@RequestMapping(value = "/{productId}", method = RequestMethod.GET)
	public ResponseEntity<Product> getProduct(@PathVariable String productId) {
		RestTemplate rest = new RestTemplate();
		ResponseEntity<Product> adidasResponse = rest.getForEntity(ADIDAS_APP_URL + productId, Product.class);

		Product product;

		if (adidasResponse.getStatusCode() == HttpStatus.OK) {
			product = adidasResponse.getBody();
		} else {
			throw new RuntimeException(adidasResponse.getStatusCode().getReasonPhrase());
		}

		ResponseEntity<Review> review = rest.getForEntity(REVIEW_APP_URL + productId, Review.class);

		if (review.getStatusCode() == HttpStatus.OK) {
			product.setReview(review.getBody());
		} else {
			throw new RuntimeException(review.getStatusCode().getReasonPhrase());
		}

		ResponseEntity<Product> productResponse = new ResponseEntity<Product>(product, adidasResponse.getStatusCode());
		return productResponse;
	}

}
