package model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "productId", "averageScore", "numberOfReviews" })
public class Review {

	@JsonProperty("productId")
	private String productId;
	@JsonProperty("averageScore")
	private Double averageScore;
	@JsonProperty("numberOfReviews")
	private Long numberOfReviews;

	@JsonProperty("productId")
	public String getProductId() {
		return productId;
	}

	@JsonProperty("productId")
	public void setProductId(String productId) {
		this.productId = productId;
	}

	@JsonProperty("averageScore")
	public Double getAverageScore() {
		return averageScore;
	}

	@JsonProperty("averageScore")
	public void setAverageScore(Double averageScore) {
		this.averageScore = averageScore;
	}

	@JsonProperty("numberOfReviews")
	public Long getNumberOfReviews() {
		return numberOfReviews;
	}

	@JsonProperty("numberOfReviews")
	public void setNumberOfReviews(Long numberOfReviews) {
		this.numberOfReviews = numberOfReviews;
	}

}
