package model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "name", "model_number", "product_type", "meta_data", "view_list", "pricing_information",
		"attribute_list", "callouts", "product_description", "breadcrumb_list", "product_link_list", "review" })
public class Product {

	@JsonProperty("id")
	private String id;
	@JsonProperty("name")
	private String name;
	@JsonProperty("model_number")
	private String modelNumber;
	@JsonProperty("product_type")
	private String productType;
	@JsonProperty("meta_data")
	private MetaData metaData;
	@JsonProperty("view_list")
	private List<ViewList> viewList = null;
	@JsonProperty("pricing_information")
	private PricingInformation pricingInformation;
	@JsonProperty("attribute_list")
	private AttributeList attributeList;
	@JsonProperty("callouts")
	private Callouts callouts;
	@JsonProperty("product_description")
	private ProductDescription productDescription;
	@JsonProperty("breadcrumb_list")
	private List<BreadcrumbList> breadcrumbList = null;
	@JsonProperty("product_link_list")
	private List<Object> productLinkList = null;

	@JsonProperty("review")
	private Review review = null;

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("model_number")
	public String getModelNumber() {
		return modelNumber;
	}

	@JsonProperty("model_number")
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	@JsonProperty("product_type")
	public String getProductType() {
		return productType;
	}

	@JsonProperty("product_type")
	public void setProductType(String productType) {
		this.productType = productType;
	}

	@JsonProperty("meta_data")
	public MetaData getMetaData() {
		return metaData;
	}

	@JsonProperty("meta_data")
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	@JsonProperty("view_list")
	public List<ViewList> getViewList() {
		return viewList;
	}

	@JsonProperty("view_list")
	public void setViewList(List<ViewList> viewList) {
		this.viewList = viewList;
	}

	@JsonProperty("pricing_information")
	public PricingInformation getPricingInformation() {
		return pricingInformation;
	}

	@JsonProperty("pricing_information")
	public void setPricingInformation(PricingInformation pricingInformation) {
		this.pricingInformation = pricingInformation;
	}

	@JsonProperty("attribute_list")
	public AttributeList getAttributeList() {
		return attributeList;
	}

	@JsonProperty("attribute_list")
	public void setAttributeList(AttributeList attributeList) {
		this.attributeList = attributeList;
	}

	@JsonProperty("callouts")
	public Callouts getCallouts() {
		return callouts;
	}

	@JsonProperty("callouts")
	public void setCallouts(Callouts callouts) {
		this.callouts = callouts;
	}

	@JsonProperty("product_description")
	public ProductDescription getProductDescription() {
		return productDescription;
	}

	@JsonProperty("product_description")
	public void setProductDescription(ProductDescription productDescription) {
		this.productDescription = productDescription;
	}

	@JsonProperty("breadcrumb_list")
	public List<BreadcrumbList> getBreadcrumbList() {
		return breadcrumbList;
	}

	@JsonProperty("breadcrumb_list")
	public void setBreadcrumbList(List<BreadcrumbList> breadcrumbList) {
		this.breadcrumbList = breadcrumbList;
	}

	@JsonProperty("product_link_list")
	public List<Object> getProductLinkList() {
		return productLinkList;
	}

	@JsonProperty("product_link_list")
	public void setProductLinkList(List<Object> productLinkList) {
		this.productLinkList = productLinkList;
	}

	@JsonProperty("review")
	public Review getReview() {
		return review;
	}

	@JsonProperty("review")
	public void setReview(Review review) {
		this.review = review;
	}

}
