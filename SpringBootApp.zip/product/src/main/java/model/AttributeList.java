package model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "isWaitingRoomProduct", "brand", "collection", "category", "color", "gender", "gender_sub",
		"personalizable", "mandatory_personalization", "customizable", "pricebook", "sale", "outlet", "sport",
		"size_chart_link", "preview_to", "coming_soon_signup", "hashtag", "productType", "sportSub", "search_color" })
public class AttributeList {

	@JsonProperty("isWaitingRoomProduct")
	private Boolean isWaitingRoomProduct;
	@JsonProperty("brand")
	private String brand;
	@JsonProperty("collection")
	private List<String> collection = null;
	@JsonProperty("category")
	private String category;
	@JsonProperty("color")
	private String color;
	@JsonProperty("gender")
	private String gender;
	@JsonProperty("gender_sub")
	private String genderSub;
	@JsonProperty("personalizable")
	private Boolean personalizable;
	@JsonProperty("mandatory_personalization")
	private Boolean mandatoryPersonalization;
	@JsonProperty("customizable")
	private Boolean customizable;
	@JsonProperty("pricebook")
	private String pricebook;
	@JsonProperty("sale")
	private Boolean sale;
	@JsonProperty("outlet")
	private Boolean outlet;
	@JsonProperty("sport")
	private List<String> sport = null;
	@JsonProperty("size_chart_link")
	private String sizeChartLink;
	@JsonProperty("preview_to")
	private String previewTo;
	@JsonProperty("coming_soon_signup")
	private Boolean comingSoonSignup;
	@JsonProperty("hashtag")
	private String hashtag;
	@JsonProperty("productType")
	private List<String> productType = null;
	@JsonProperty("sportSub")
	private List<String> sportSub = null;
	@JsonProperty("search_color")
	private String searchColor;

	@JsonProperty("isWaitingRoomProduct")
	public Boolean getIsWaitingRoomProduct() {
		return isWaitingRoomProduct;
	}

	@JsonProperty("isWaitingRoomProduct")
	public void setIsWaitingRoomProduct(Boolean isWaitingRoomProduct) {
		this.isWaitingRoomProduct = isWaitingRoomProduct;
	}

	@JsonProperty("brand")
	public String getBrand() {
		return brand;
	}

	@JsonProperty("brand")
	public void setBrand(String brand) {
		this.brand = brand;
	}

	@JsonProperty("collection")
	public List<String> getCollection() {
		return collection;
	}

	@JsonProperty("collection")
	public void setCollection(List<String> collection) {
		this.collection = collection;
	}

	@JsonProperty("category")
	public String getCategory() {
		return category;
	}

	@JsonProperty("category")
	public void setCategory(String category) {
		this.category = category;
	}

	@JsonProperty("color")
	public String getColor() {
		return color;
	}

	@JsonProperty("color")
	public void setColor(String color) {
		this.color = color;
	}

	@JsonProperty("gender")
	public String getGender() {
		return gender;
	}

	@JsonProperty("gender")
	public void setGender(String gender) {
		this.gender = gender;
	}

	@JsonProperty("gender_sub")
	public String getGenderSub() {
		return genderSub;
	}

	@JsonProperty("gender_sub")
	public void setGenderSub(String genderSub) {
		this.genderSub = genderSub;
	}

	@JsonProperty("personalizable")
	public Boolean getPersonalizable() {
		return personalizable;
	}

	@JsonProperty("personalizable")
	public void setPersonalizable(Boolean personalizable) {
		this.personalizable = personalizable;
	}

	@JsonProperty("mandatory_personalization")
	public Boolean getMandatoryPersonalization() {
		return mandatoryPersonalization;
	}

	@JsonProperty("mandatory_personalization")
	public void setMandatoryPersonalization(Boolean mandatoryPersonalization) {
		this.mandatoryPersonalization = mandatoryPersonalization;
	}

	@JsonProperty("customizable")
	public Boolean getCustomizable() {
		return customizable;
	}

	@JsonProperty("customizable")
	public void setCustomizable(Boolean customizable) {
		this.customizable = customizable;
	}

	@JsonProperty("pricebook")
	public String getPricebook() {
		return pricebook;
	}

	@JsonProperty("pricebook")
	public void setPricebook(String pricebook) {
		this.pricebook = pricebook;
	}

	@JsonProperty("sale")
	public Boolean getSale() {
		return sale;
	}

	@JsonProperty("sale")
	public void setSale(Boolean sale) {
		this.sale = sale;
	}

	@JsonProperty("outlet")
	public Boolean getOutlet() {
		return outlet;
	}

	@JsonProperty("outlet")
	public void setOutlet(Boolean outlet) {
		this.outlet = outlet;
	}

	@JsonProperty("sport")
	public List<String> getSport() {
		return sport;
	}

	@JsonProperty("sport")
	public void setSport(List<String> sport) {
		this.sport = sport;
	}

	@JsonProperty("size_chart_link")
	public String getSizeChartLink() {
		return sizeChartLink;
	}

	@JsonProperty("size_chart_link")
	public void setSizeChartLink(String sizeChartLink) {
		this.sizeChartLink = sizeChartLink;
	}

	@JsonProperty("preview_to")
	public String getPreviewTo() {
		return previewTo;
	}

	@JsonProperty("preview_to")
	public void setPreviewTo(String previewTo) {
		this.previewTo = previewTo;
	}

	@JsonProperty("coming_soon_signup")
	public Boolean getComingSoonSignup() {
		return comingSoonSignup;
	}

	@JsonProperty("coming_soon_signup")
	public void setComingSoonSignup(Boolean comingSoonSignup) {
		this.comingSoonSignup = comingSoonSignup;
	}

	@JsonProperty("hashtag")
	public String getHashtag() {
		return hashtag;
	}

	@JsonProperty("hashtag")
	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}

	@JsonProperty("productType")
	public List<String> getProductType() {
		return productType;
	}

	@JsonProperty("productType")
	public void setProductType(List<String> productType) {
		this.productType = productType;
	}

	@JsonProperty("sportSub")
	public List<String> getSportSub() {
		return sportSub;
	}

	@JsonProperty("sportSub")
	public void setSportSub(List<String> sportSub) {
		this.sportSub = sportSub;
	}

	@JsonProperty("search_color")
	public String getSearchColor() {
		return searchColor;
	}

	@JsonProperty("search_color")
	public void setSearchColor(String searchColor) {
		this.searchColor = searchColor;
	}

}
