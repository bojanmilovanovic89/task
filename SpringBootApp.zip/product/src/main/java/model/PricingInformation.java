package model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "standard_price", "standard_price_no_vat", "currentPrice" })
public class PricingInformation {

	@JsonProperty("standard_price")
	private Double standardPrice;
	@JsonProperty("standard_price_no_vat")
	private Double standardPriceNoVat;
	@JsonProperty("currentPrice")
	private Double currentPrice;

	@JsonProperty("standard_price")
	public Double getStandardPrice() {
		return standardPrice;
	}

	@JsonProperty("standard_price")
	public void setStandardPrice(Double standardPrice) {
		this.standardPrice = standardPrice;
	}

	@JsonProperty("standard_price_no_vat")
	public Double getStandardPriceNoVat() {
		return standardPriceNoVat;
	}

	@JsonProperty("standard_price_no_vat")
	public void setStandardPriceNoVat(Double standardPriceNoVat) {
		this.standardPriceNoVat = standardPriceNoVat;
	}

	@JsonProperty("currentPrice")
	public Double getCurrentPrice() {
		return currentPrice;
	}

	@JsonProperty("currentPrice")
	public void setCurrentPrice(Double currentPrice) {
		this.currentPrice = currentPrice;
	}

}
