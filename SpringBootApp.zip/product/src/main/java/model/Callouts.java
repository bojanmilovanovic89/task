package model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "callout_bottom_stack" })
public class Callouts {

	@JsonProperty("callout_bottom_stack")
	private CalloutBottomStack calloutBottomStack;

	@JsonProperty("callout_bottom_stack")
	public CalloutBottomStack getCalloutBottomStack() {
		return calloutBottomStack;
	}

	@JsonProperty("callout_bottom_stack")
	public void setCalloutBottomStack(CalloutBottomStack calloutBottomStack) {
		this.calloutBottomStack = calloutBottomStack;
	}

}
